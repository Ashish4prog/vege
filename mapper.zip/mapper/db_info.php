<?php
    $username = "root";
    $pass = "";
    $db = "vege";
?>